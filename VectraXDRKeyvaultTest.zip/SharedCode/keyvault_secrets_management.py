"""This file is used for accessing keyvault to get or set secrets."""
import os
from SharedCode import logger
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
import logging
from azure.core.exceptions import ResourceNotFoundError
from ..SharedCode import consts
import time




class KeyVaultSecretManage:
    """This class contains methods to authenticate with Azure KeyVault and get or set secrets in keyvault."""

    def __init__(self) -> None:
        """Intialize instance variables for class."""
        self.keyvault_name = consts.KEY_VAULT_NAME
        self.keyvault_uri = "https://{}.vault.azure.net/".format(self.keyvault_name)
        self.client = self.get_client()

    def get_client(self):
        """To obtain AzureKeyVault client.

        Returns:
            SecretClient: returns client object for accessing AzureKeyVault.
        """
        credential = DefaultAzureCredential()
        client = SecretClient(vault_url=self.keyvault_uri, credential=credential)
        return client

    def get_keyvault_secret(self, secret_name):
        """To get value of provided secretname from AzureKeyVault.

        Args:
            secret_name (str): secret name to get its value.
        """
        try:
            logging.debug("Retrieving secret {} from {}.".format(secret_name, self.keyvault_name))
            retrieved_secret = self.client.get_secret(secret_name)
            logging.debug("Retrieved secret value is '{}' for {}.".format(retrieved_secret.value, retrieved_secret.name))
            return retrieved_secret.value
            
        except ResourceNotFoundError as err :
            logging.error("Resource not found : '{}' ".format(err))
            self.set_keyvault_secret(secret_name,"") 

    def set_keyvault_secret(self, secret_name, secret_value):
        """To update secret value of given secret name or create new secret.

        Args:
            secret_name (str): secret name to update its value or create it.
            secret_value (str): secret value to be set as value of given secret name.
        """
        logging.debug("Creating or updating a secret called '{}' with the value '{}'.".format(secret_name, secret_value))
        self.client.set_secret(secret_name, secret_value)
        logging.debug("Secret created successfully : '{}' .".format(secret_name))

    def get_properties_list_of_secrets(self):
        """To get list of secrets stored in keyvault with its properties.

        Returns:
            list: _description_
        """
        secret_properties = self.client.list_properties_of_secrets()
        properties_list = [secret_property.name for secret_property in secret_properties]
        return properties_list

    # def delete_secret(self , secret_name):
    #     """Will delete all the previously stored secrets

    #     Args:
    #         secret_name (str): Name of secret to be deleted

    #     Raises:
    #         Exception: _description_
    #     """
    #     # try :
    #     if self.client.get_secret(secret_name) :
    #         self.client.begin_delete_secret(secret_name)
    #         time.sleep(3)
    #         self.client.purge_deleted_secret(secret_name)
            
    #         logging.error("Secret Deleted Successfully : '{}'".format(secret_name))
    #     else:
    #         logging.error("Secret Not Found")
    #     # except ResourceNotFoundError as err :
    #     #     raise Exception("Error while deleting secret : {}".format(err))